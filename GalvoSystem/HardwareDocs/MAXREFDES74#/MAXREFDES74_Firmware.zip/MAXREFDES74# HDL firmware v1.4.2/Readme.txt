Copyright � 2014 Maxim Integrated Products, Inc.

BOOT.BIN is the HDL/firmware for Zedboard to control MAXREFDES74#.

To use this file, please follow the procedure below.

1. Please verify Zedboard VADJ SELECT J18 is placed on 3V3 position. If not, please solder 2-pin male header on 3V3 position and put a shunt. 

2. Please verify Zedboard MIO2 to MIO6 are configured as booting from SD Card. MIO2, MIO3 and MIO6 are on SIG-GND position. MIO4 and MIO5 are on SIG-3V3 position.

3. Copy BOOT.BIN to your SD card. Please place the file under root folder and do NOT change the file name. 

4. Insert SD card into Zedboard. Press PR_RST button to load the new firmware.

5. You can see "MAXREFDES74 v1.4.2 � 2014" is shown on OLED display. The Zedboard is ready to use.