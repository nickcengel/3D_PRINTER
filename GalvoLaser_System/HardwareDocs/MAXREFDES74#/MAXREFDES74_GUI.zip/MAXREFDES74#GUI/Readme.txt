Copyright � 2014 Maxim Integrated Products, Inc.

MAXREFDES74# software is developed in LabView 2013 platform.

If the PC does not have LabView 2013 or LabView 2013 runtime engine installed already, please go to 

http://www.ni.com/download/labview-run-time-engine-2013/4059/en/

download and install it.

After successfully installed the runtime engine, unzip the MAXREFDES74# software folder, and run MAXREFDES74#.exe to start to GUI.

To create a shortcut on desktop, right click MAXREFDES74#.exe and select "Send to Desktop".

This software does not need uninstallation. If you does not need MAXREFDES74# software anymore, delete MAXREFDES74# folder and desktop shortcut directly.
